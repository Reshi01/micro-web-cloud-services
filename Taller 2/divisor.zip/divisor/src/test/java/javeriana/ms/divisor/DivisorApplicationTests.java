package javeriana.ms.divisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DivisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
