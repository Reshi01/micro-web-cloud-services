package javeriana.ms.multiplicador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiplicadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
