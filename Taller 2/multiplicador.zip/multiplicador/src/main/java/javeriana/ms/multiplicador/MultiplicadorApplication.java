package javeriana.ms.multiplicador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiplicadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiplicadorApplication.class, args);
	}

}
